"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.listEligibleWindowsAgents = listEligibleWindowsAgents;
exports.registerAgentRoutes = registerAgentRoutes;
var _configSchema = require("@osd/config-schema");
var _wazuh_client = require("../services/wazuh_client");
async function listEligibleWindowsAgents() {
  // Page through the complete enrolled-agent list; never silently cap the selector at 500.
  const items = [];
  const pageSize = 500;
  for (let offset = 0; offset < 100000; offset += pageSize) {
    var _result$data$affected, _result$data, _result$data$total_af, _result$data2;
    const result = await (0, _wazuh_client.wazuhGet)(`/agents?limit=${pageSize}&offset=${offset}&select=id,name,status,os.name,os.platform,os.version`);
    const page = (_result$data$affected = result === null || result === void 0 || (_result$data = result.data) === null || _result$data === void 0 ? void 0 : _result$data.affected_items) !== null && _result$data$affected !== void 0 ? _result$data$affected : [];
    items.push(...page);
    if (page.length < pageSize || items.length >= Number((_result$data$total_af = result === null || result === void 0 || (_result$data2 = result.data) === null || _result$data2 === void 0 ? void 0 : _result$data2.total_affected_items) !== null && _result$data$total_af !== void 0 ? _result$data$total_af : 0)) break;
  }
  return items.filter(a => {
    var _a$os$name, _a$os, _a$os$platform, _a$os2, _a$os$version, _a$os3;
    const os = `${(_a$os$name = a === null || a === void 0 || (_a$os = a.os) === null || _a$os === void 0 ? void 0 : _a$os.name) !== null && _a$os$name !== void 0 ? _a$os$name : ''} ${(_a$os$platform = a === null || a === void 0 || (_a$os2 = a.os) === null || _a$os2 === void 0 ? void 0 : _a$os2.platform) !== null && _a$os$platform !== void 0 ? _a$os$platform : ''} ${(_a$os$version = a === null || a === void 0 || (_a$os3 = a.os) === null || _a$os3 === void 0 ? void 0 : _a$os3.version) !== null && _a$os$version !== void 0 ? _a$os$version : ''}`.toLowerCase();
    return a.status === 'active' && (os.includes('windows') || os.includes('microsoft'));
  }).map(a => {
    var _a$name, _a$os4, _a$os5;
    return {
      id: String(a.id),
      name: String((_a$name = a.name) !== null && _a$name !== void 0 ? _a$name : a.id),
      status: String(a.status),
      os: [a === null || a === void 0 || (_a$os4 = a.os) === null || _a$os4 === void 0 ? void 0 : _a$os4.name, a === null || a === void 0 || (_a$os5 = a.os) === null || _a$os5 === void 0 ? void 0 : _a$os5.version].filter(Boolean).join(' ')
    };
  });
}
function registerAgentRoutes(router) {
  router.get({
    path: '/api/df-acquisition/agents',
    validate: {
      query: _configSchema.schema.object({})
    }
  }, async (context, request, response) => {
    try {
      const agents = await listEligibleWindowsAgents();
      return response.ok({
        body: {
          agents
        }
      });
    } catch (error) {
      return response.customError({
        statusCode: 502,
        body: {
          code: 'WAZUH_API_ERROR',
          message: error instanceof Error ? error.message : 'Could not retrieve agents'
        }
      });
    }
  });
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uZmlnU2NoZW1hIiwicmVxdWlyZSIsIl93YXp1aF9jbGllbnQiLCJsaXN0RWxpZ2libGVXaW5kb3dzQWdlbnRzIiwiaXRlbXMiLCJwYWdlU2l6ZSIsIm9mZnNldCIsIl9yZXN1bHQkZGF0YSRhZmZlY3RlZCIsIl9yZXN1bHQkZGF0YSIsIl9yZXN1bHQkZGF0YSR0b3RhbF9hZiIsIl9yZXN1bHQkZGF0YTIiLCJyZXN1bHQiLCJ3YXp1aEdldCIsInBhZ2UiLCJkYXRhIiwiYWZmZWN0ZWRfaXRlbXMiLCJwdXNoIiwibGVuZ3RoIiwiTnVtYmVyIiwidG90YWxfYWZmZWN0ZWRfaXRlbXMiLCJmaWx0ZXIiLCJhIiwiX2Ekb3MkbmFtZSIsIl9hJG9zIiwiX2Ekb3MkcGxhdGZvcm0iLCJfYSRvczIiLCJfYSRvcyR2ZXJzaW9uIiwiX2Ekb3MzIiwib3MiLCJuYW1lIiwicGxhdGZvcm0iLCJ2ZXJzaW9uIiwidG9Mb3dlckNhc2UiLCJzdGF0dXMiLCJpbmNsdWRlcyIsIm1hcCIsIl9hJG5hbWUiLCJfYSRvczQiLCJfYSRvczUiLCJpZCIsIlN0cmluZyIsIkJvb2xlYW4iLCJqb2luIiwicmVnaXN0ZXJBZ2VudFJvdXRlcyIsInJvdXRlciIsImdldCIsInBhdGgiLCJ2YWxpZGF0ZSIsInF1ZXJ5Iiwic2NoZW1hIiwib2JqZWN0IiwiY29udGV4dCIsInJlcXVlc3QiLCJyZXNwb25zZSIsImFnZW50cyIsIm9rIiwiYm9keSIsImVycm9yIiwiY3VzdG9tRXJyb3IiLCJzdGF0dXNDb2RlIiwiY29kZSIsIm1lc3NhZ2UiLCJFcnJvciJdLCJzb3VyY2VzIjpbImFnZW50cy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBzY2hlbWEgfSBmcm9tICdAb3NkL2NvbmZpZy1zY2hlbWEnO1xuaW1wb3J0IHsgSVJvdXRlciB9IGZyb20gJy4uLy4uLy4uLy4uL3NyYy9jb3JlL3NlcnZlcic7XG5pbXBvcnQgeyB3YXp1aEdldCB9IGZyb20gJy4uL3NlcnZpY2VzL3dhenVoX2NsaWVudCc7XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBsaXN0RWxpZ2libGVXaW5kb3dzQWdlbnRzKCkge1xuICAvLyBQYWdlIHRocm91Z2ggdGhlIGNvbXBsZXRlIGVucm9sbGVkLWFnZW50IGxpc3Q7IG5ldmVyIHNpbGVudGx5IGNhcCB0aGUgc2VsZWN0b3IgYXQgNTAwLlxuICBjb25zdCBpdGVtczogYW55W10gPSBbXTtcbiAgY29uc3QgcGFnZVNpemUgPSA1MDA7XG4gIGZvciAobGV0IG9mZnNldCA9IDA7IG9mZnNldCA8IDEwMDAwMDsgb2Zmc2V0ICs9IHBhZ2VTaXplKSB7XG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgd2F6dWhHZXQoYC9hZ2VudHM/bGltaXQ9JHtwYWdlU2l6ZX0mb2Zmc2V0PSR7b2Zmc2V0fSZzZWxlY3Q9aWQsbmFtZSxzdGF0dXMsb3MubmFtZSxvcy5wbGF0Zm9ybSxvcy52ZXJzaW9uYCk7XG4gICAgY29uc3QgcGFnZSA9IHJlc3VsdD8uZGF0YT8uYWZmZWN0ZWRfaXRlbXMgPz8gW107XG4gICAgaXRlbXMucHVzaCguLi5wYWdlKTtcbiAgICBpZiAocGFnZS5sZW5ndGggPCBwYWdlU2l6ZSB8fCBpdGVtcy5sZW5ndGggPj0gTnVtYmVyKHJlc3VsdD8uZGF0YT8udG90YWxfYWZmZWN0ZWRfaXRlbXMgPz8gMCkpIGJyZWFrO1xuICB9XG4gIHJldHVybiBpdGVtcy5maWx0ZXIoKGE6IGFueSkgPT4ge1xuICAgIGNvbnN0IG9zID0gYCR7YT8ub3M/Lm5hbWUgPz8gJyd9ICR7YT8ub3M/LnBsYXRmb3JtID8/ICcnfSAke2E/Lm9zPy52ZXJzaW9uID8/ICcnfWAudG9Mb3dlckNhc2UoKTtcbiAgICByZXR1cm4gYS5zdGF0dXMgPT09ICdhY3RpdmUnICYmIChvcy5pbmNsdWRlcygnd2luZG93cycpIHx8IG9zLmluY2x1ZGVzKCdtaWNyb3NvZnQnKSk7XG4gIH0pLm1hcCgoYTogYW55KSA9PiAoe1xuICAgIGlkOiBTdHJpbmcoYS5pZCksIG5hbWU6IFN0cmluZyhhLm5hbWUgPz8gYS5pZCksIHN0YXR1czogU3RyaW5nKGEuc3RhdHVzKSxcbiAgICBvczogW2E/Lm9zPy5uYW1lLCBhPy5vcz8udmVyc2lvbl0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oJyAnKSxcbiAgfSkpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gcmVnaXN0ZXJBZ2VudFJvdXRlcyhyb3V0ZXI6IElSb3V0ZXIpIHtcbiAgcm91dGVyLmdldCh7IHBhdGg6ICcvYXBpL2RmLWFjcXVpc2l0aW9uL2FnZW50cycsIHZhbGlkYXRlOiB7IHF1ZXJ5OiBzY2hlbWEub2JqZWN0KHt9KSB9IH0sIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBhZ2VudHMgPSBhd2FpdCBsaXN0RWxpZ2libGVXaW5kb3dzQWdlbnRzKCk7XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiB7IGFnZW50cyB9IH0pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICByZXR1cm4gcmVzcG9uc2UuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA1MDIsIGJvZHk6IHsgY29kZTogJ1dBWlVIX0FQSV9FUlJPUicsIG1lc3NhZ2U6IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogJ0NvdWxkIG5vdCByZXRyaWV2ZSBhZ2VudHMnIH0gfSk7XG4gICAgfVxuICB9KTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUFBLElBQUFBLGFBQUEsR0FBQUMsT0FBQTtBQUVBLElBQUFDLGFBQUEsR0FBQUQsT0FBQTtBQUVPLGVBQWVFLHlCQUF5QkEsQ0FBQSxFQUFHO0VBQ2hEO0VBQ0EsTUFBTUMsS0FBWSxHQUFHLEVBQUU7RUFDdkIsTUFBTUMsUUFBUSxHQUFHLEdBQUc7RUFDcEIsS0FBSyxJQUFJQyxNQUFNLEdBQUcsQ0FBQyxFQUFFQSxNQUFNLEdBQUcsTUFBTSxFQUFFQSxNQUFNLElBQUlELFFBQVEsRUFBRTtJQUFBLElBQUFFLHFCQUFBLEVBQUFDLFlBQUEsRUFBQUMscUJBQUEsRUFBQUMsYUFBQTtJQUN4RCxNQUFNQyxNQUFNLEdBQUcsTUFBTSxJQUFBQyxzQkFBUSxFQUFFLGlCQUFnQlAsUUFBUyxXQUFVQyxNQUFPLHVEQUFzRCxDQUFDO0lBQ2hJLE1BQU1PLElBQUksSUFBQU4scUJBQUEsR0FBR0ksTUFBTSxhQUFOQSxNQUFNLGdCQUFBSCxZQUFBLEdBQU5HLE1BQU0sQ0FBRUcsSUFBSSxjQUFBTixZQUFBLHVCQUFaQSxZQUFBLENBQWNPLGNBQWMsY0FBQVIscUJBQUEsY0FBQUEscUJBQUEsR0FBSSxFQUFFO0lBQy9DSCxLQUFLLENBQUNZLElBQUksQ0FBQyxHQUFHSCxJQUFJLENBQUM7SUFDbkIsSUFBSUEsSUFBSSxDQUFDSSxNQUFNLEdBQUdaLFFBQVEsSUFBSUQsS0FBSyxDQUFDYSxNQUFNLElBQUlDLE1BQU0sRUFBQVQscUJBQUEsR0FBQ0UsTUFBTSxhQUFOQSxNQUFNLGdCQUFBRCxhQUFBLEdBQU5DLE1BQU0sQ0FBRUcsSUFBSSxjQUFBSixhQUFBLHVCQUFaQSxhQUFBLENBQWNTLG9CQUFvQixjQUFBVixxQkFBQSxjQUFBQSxxQkFBQSxHQUFJLENBQUMsQ0FBQyxFQUFFO0VBQ2pHO0VBQ0EsT0FBT0wsS0FBSyxDQUFDZ0IsTUFBTSxDQUFFQyxDQUFNLElBQUs7SUFBQSxJQUFBQyxVQUFBLEVBQUFDLEtBQUEsRUFBQUMsY0FBQSxFQUFBQyxNQUFBLEVBQUFDLGFBQUEsRUFBQUMsTUFBQTtJQUM5QixNQUFNQyxFQUFFLEdBQUksSUFBQU4sVUFBQSxHQUFFRCxDQUFDLGFBQURBLENBQUMsZ0JBQUFFLEtBQUEsR0FBREYsQ0FBQyxDQUFFTyxFQUFFLGNBQUFMLEtBQUEsdUJBQUxBLEtBQUEsQ0FBT00sSUFBSSxjQUFBUCxVQUFBLGNBQUFBLFVBQUEsR0FBSSxFQUFHLElBQUMsQ0FBQUUsY0FBQSxHQUFFSCxDQUFDLGFBQURBLENBQUMsZ0JBQUFJLE1BQUEsR0FBREosQ0FBQyxDQUFFTyxFQUFFLGNBQUFILE1BQUEsdUJBQUxBLE1BQUEsQ0FBT0ssUUFBUSxjQUFBTixjQUFBLGNBQUFBLGNBQUEsR0FBSSxFQUFHLElBQUMsQ0FBQUUsYUFBQSxHQUFFTCxDQUFDLGFBQURBLENBQUMsZ0JBQUFNLE1BQUEsR0FBRE4sQ0FBQyxDQUFFTyxFQUFFLGNBQUFELE1BQUEsdUJBQUxBLE1BQUEsQ0FBT0ksT0FBTyxjQUFBTCxhQUFBLGNBQUFBLGFBQUEsR0FBSSxFQUFHLEVBQUMsQ0FBQ00sV0FBVyxDQUFDLENBQUM7SUFDaEcsT0FBT1gsQ0FBQyxDQUFDWSxNQUFNLEtBQUssUUFBUSxLQUFLTCxFQUFFLENBQUNNLFFBQVEsQ0FBQyxTQUFTLENBQUMsSUFBSU4sRUFBRSxDQUFDTSxRQUFRLENBQUMsV0FBVyxDQUFDLENBQUM7RUFDdEYsQ0FBQyxDQUFDLENBQUNDLEdBQUcsQ0FBRWQsQ0FBTTtJQUFBLElBQUFlLE9BQUEsRUFBQUMsTUFBQSxFQUFBQyxNQUFBO0lBQUEsT0FBTTtNQUNsQkMsRUFBRSxFQUFFQyxNQUFNLENBQUNuQixDQUFDLENBQUNrQixFQUFFLENBQUM7TUFBRVYsSUFBSSxFQUFFVyxNQUFNLEVBQUFKLE9BQUEsR0FBQ2YsQ0FBQyxDQUFDUSxJQUFJLGNBQUFPLE9BQUEsY0FBQUEsT0FBQSxHQUFJZixDQUFDLENBQUNrQixFQUFFLENBQUM7TUFBRU4sTUFBTSxFQUFFTyxNQUFNLENBQUNuQixDQUFDLENBQUNZLE1BQU0sQ0FBQztNQUN4RUwsRUFBRSxFQUFFLENBQUNQLENBQUMsYUFBREEsQ0FBQyxnQkFBQWdCLE1BQUEsR0FBRGhCLENBQUMsQ0FBRU8sRUFBRSxjQUFBUyxNQUFBLHVCQUFMQSxNQUFBLENBQU9SLElBQUksRUFBRVIsQ0FBQyxhQUFEQSxDQUFDLGdCQUFBaUIsTUFBQSxHQUFEakIsQ0FBQyxDQUFFTyxFQUFFLGNBQUFVLE1BQUEsdUJBQUxBLE1BQUEsQ0FBT1AsT0FBTyxDQUFDLENBQUNYLE1BQU0sQ0FBQ3FCLE9BQU8sQ0FBQyxDQUFDQyxJQUFJLENBQUMsR0FBRztJQUM1RCxDQUFDO0VBQUEsQ0FBQyxDQUFDO0FBQ0w7QUFFTyxTQUFTQyxtQkFBbUJBLENBQUNDLE1BQWUsRUFBRTtFQUNuREEsTUFBTSxDQUFDQyxHQUFHLENBQUM7SUFBRUMsSUFBSSxFQUFFLDRCQUE0QjtJQUFFQyxRQUFRLEVBQUU7TUFBRUMsS0FBSyxFQUFFQyxvQkFBTSxDQUFDQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0lBQUU7RUFBRSxDQUFDLEVBQUUsT0FBT0MsT0FBTyxFQUFFQyxPQUFPLEVBQUVDLFFBQVEsS0FBSztJQUMvSCxJQUFJO01BQ0YsTUFBTUMsTUFBTSxHQUFHLE1BQU1uRCx5QkFBeUIsQ0FBQyxDQUFDO01BQ2hELE9BQU9rRCxRQUFRLENBQUNFLEVBQUUsQ0FBQztRQUFFQyxJQUFJLEVBQUU7VUFBRUY7UUFBTztNQUFFLENBQUMsQ0FBQztJQUMxQyxDQUFDLENBQUMsT0FBT0csS0FBSyxFQUFFO01BQ2QsT0FBT0osUUFBUSxDQUFDSyxXQUFXLENBQUM7UUFBRUMsVUFBVSxFQUFFLEdBQUc7UUFBRUgsSUFBSSxFQUFFO1VBQUVJLElBQUksRUFBRSxpQkFBaUI7VUFBRUMsT0FBTyxFQUFFSixLQUFLLFlBQVlLLEtBQUssR0FBR0wsS0FBSyxDQUFDSSxPQUFPLEdBQUc7UUFBNEI7TUFBRSxDQUFDLENBQUM7SUFDcEs7RUFDRixDQUFDLENBQUM7QUFDSiJ9